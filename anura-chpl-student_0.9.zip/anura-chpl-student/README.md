# Anura

A framework for learning how to build an Aura Proof of Authority algorithm, written in Chapel
